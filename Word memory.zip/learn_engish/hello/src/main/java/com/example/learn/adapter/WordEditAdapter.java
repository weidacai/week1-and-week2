package com.example.learn.adapter;

public class WordEditAdapter {

}
